// Correct way to define an enum-like object in JavaScript
exports.ENUM_USER_ROLE = {
    SUPER_ADMIN: 'super_admin',
    ADMIN: 'admin',
    USER: 'user',
   
  };
  