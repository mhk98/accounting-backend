//  const SaleSearchAbleFields = ['name', , 'startMonth', 'endMonth'];

 const SaleFilterAbleFileds = [ 'startMonth', 'endMonth'];

 module.exports = {
  
    SaleFilterAbleFileds
 }