//  const SupplierSearchAbleFields = ['name', , 'startMonth', 'endMonth'];

 const SupplierFilterAbleFileds = [ 'startMonth', 'endMonth'];

 module.exports = {
    SupplierFilterAbleFileds,
    
 }