//  const PurchaseSearchAbleFields = ['name', , 'startMonth', 'endMonth'];

 const PurchaseFilterAbleFileds = [ 'startMonth', 'endMonth'];

 module.exports = {
    
    PurchaseFilterAbleFileds
 }