//  const ProductSearchAbleFields = ['name', 'startDate', 'endDate'];

 const ProductFilterAbleFileds = [ 'startDate', 'endDate'];

module.exports = {

    ProductFilterAbleFileds
}