 const UserSearchAbleFields = ['name', , 'startMonth', 'endMonth'];

 const UserFilterAbleFileds = ['searchTerm', 'startMonth', 'endMonth'];

 module.exports = {
    UserSearchAbleFields,
    UserFilterAbleFileds
 }