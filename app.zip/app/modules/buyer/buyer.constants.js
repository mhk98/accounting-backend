//  const BuyerSearchAbleFields = ['name', , 'startMonth', 'endMonth'];

 const BuyerFilterAbleFileds = [ 'startMonth', 'endMonth'];

module.exports = {
    BuyerFilterAbleFileds
}